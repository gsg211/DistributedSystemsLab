package com.sd.lab3.Chain.ChainTest

import com.sd.lab3.Chain.ChainNext
import com.sd.lab3.Chain.Chainable

@ChainNext(Node3::class)
class Node2 : Chainable<String, Double> {
    override fun proceed(input: String): Double {
        println(input)
        if(input=="world")
        {
            return 6.7
        }
        return -1.0
    }

}