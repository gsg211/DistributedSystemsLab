package com.sd.lab3.Chain.ChainTest

import com.sd.lab3.Chain.ChainNext
import com.sd.lab3.Chain.ChainRunner
import com.sd.lab3.Chain.Chainable

@ChainNext(Node2::class)
class Node1 : Chainable<String, String>{
    override fun proceed(input: String): String {
        println(input)
        if(input=="hello")
        {
            return "world"
        }
        return "bad"
    }
}

fun main()
{
    val chain= ChainRunner(Node1::class)
    chain.execute("hello")

}