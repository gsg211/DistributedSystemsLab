package com.sd.lab3.Chain.ChainTest

import com.sd.lab3.Chain.Chainable
import kotlin.math.round

class Node3: Chainable<Double, Double> {
    override fun proceed(input: Double): Double {
        println(input)
        return round(input)
    }

}